package com.cognizant.performancecheck.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Products implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4527062922183180743L;
	
	
	private List<Product> product;
	
	@XmlElement(name = "product")
	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}
	
	@XmlAttribute(name="id")
	protected String productsId;
		
	public String getProductsId() {
		return productsId;
	}
	public void setProductId(String productsId) {
		this.productsId = productsId;
	}
	
}
