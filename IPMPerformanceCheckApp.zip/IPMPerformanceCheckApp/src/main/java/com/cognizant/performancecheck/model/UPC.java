package com.cognizant.performancecheck.model;

import javax.xml.bind.annotation.XmlAttribute;


public class UPC {
	
	private String upcType;
	
	@XmlAttribute(name = "type")
	public String getUpcType() {
		return upcType;
	}

	public void setUpcType(String upcType) {
		this.upcType = upcType;
	}
	
}
