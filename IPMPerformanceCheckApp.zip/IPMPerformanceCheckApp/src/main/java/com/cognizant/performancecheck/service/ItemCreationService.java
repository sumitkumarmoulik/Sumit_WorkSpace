package com.cognizant.performancecheck.service;

import java.sql.SQLException;

import com.cognizant.performancecheck.model.ItemInput;
import com.cognizant.performancecheck.model.ItemsUpdated;

public interface ItemCreationService {
	public ItemsUpdated createItems(ItemInput itemInput) throws SQLException,Exception;
}
