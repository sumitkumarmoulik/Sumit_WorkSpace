package com.cognizant.performancecheck.model;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "items")
@XmlSeeAlso(value = Item.class)
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemRoot {
	/**
	 * ItemRoot
	 */
	@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T04:37:54.797Z")
	
	@XmlElement(name = "item")
	private List<Item> itemInputString ;
	
	
	public List<Item> getItemInputString() {
		return itemInputString;
	}


	public void setItemInputString(List<Item> itemInputString) {
		this.itemInputString = itemInputString;
	}
	
	@Override
	public String toString() {
		return "ItemInput [itemInputString=" + itemInputString + "]";
	}

}
