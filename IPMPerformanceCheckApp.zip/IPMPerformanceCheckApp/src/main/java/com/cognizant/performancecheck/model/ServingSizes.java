package com.cognizant.performancecheck.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class ServingSizes implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2143645126871652129L;
	
	private List<ServingSize> servingSize;

	@XmlElement(name = "servingSize")
	public List<ServingSize> getServingSize() {
		return servingSize;
	}

	public void setServingSize(List<ServingSize> servingSize) {
		this.servingSize = servingSize;
	}
}
