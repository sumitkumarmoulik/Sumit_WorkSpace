package com.cognizant.performancecheck.dataobjects;

import java.sql.SQLException;

import com.cognizant.performancecheck.model.ItemInput;
import com.cognizant.performancecheck.model.ItemsUpdated;

public interface ItemCreationDataObject {
	public ItemsUpdated createItems(ItemInput itemInput) throws SQLException,Exception;
}
