package com.cognizant.performancecheck.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ItemsUpdatedItems
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T04:37:54.797Z")

public class ItemsUpdatedItems   {
  @JsonProperty("NumberofItemsUpdated")
  private Integer numberofItemsUpdated = null;

  @JsonProperty("NumberofProductsUpdated")
  private Integer numberofProductsUpdated = null;

  @JsonProperty("NumberofNutritionsUpdated")
  private Integer numberofNutritionsUpdated = null;

  public ItemsUpdatedItems numberofItemsUpdated(Integer numberofItemsUpdated) {
    this.numberofItemsUpdated = numberofItemsUpdated;
    return this;
  }

   /**
   * Get numberofItemsUpdated
   * @return numberofItemsUpdated
  **/
  @ApiModelProperty(value = "")


  public Integer getNumberofItemsUpdated() {
    return numberofItemsUpdated;
  }

  public void setNumberofItemsUpdated(Integer numberofItemsUpdated) {
    this.numberofItemsUpdated = numberofItemsUpdated;
  }

  public ItemsUpdatedItems numberofProductsUpdated(Integer numberofProductsUpdated) {
    this.numberofProductsUpdated = numberofProductsUpdated;
    return this;
  }

   /**
   * Get numberofProductsUpdated
   * @return numberofProductsUpdated
  **/
  @ApiModelProperty(value = "")


  public Integer getNumberofProductsUpdated() {
    return numberofProductsUpdated;
  }

  public void setNumberofProductsUpdated(Integer numberofProductsUpdated) {
    this.numberofProductsUpdated = numberofProductsUpdated;
  }

  public ItemsUpdatedItems numberofNutritionsUpdated(Integer numberofNutritionsUpdated) {
    this.numberofNutritionsUpdated = numberofNutritionsUpdated;
    return this;
  }

   /**
   * Get numberofNutritionsUpdated
   * @return numberofNutritionsUpdated
  **/
  @ApiModelProperty(value = "")


  public Integer getNumberofNutritionsUpdated() {
    return numberofNutritionsUpdated;
  }

  public void setNumberofNutritionsUpdated(Integer numberofNutritionsUpdated) {
    this.numberofNutritionsUpdated = numberofNutritionsUpdated;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ItemsUpdatedItems itemsUpdatedItems = (ItemsUpdatedItems) o;
    return Objects.equals(this.numberofItemsUpdated, itemsUpdatedItems.numberofItemsUpdated) &&
        Objects.equals(this.numberofProductsUpdated, itemsUpdatedItems.numberofProductsUpdated) &&
        Objects.equals(this.numberofNutritionsUpdated, itemsUpdatedItems.numberofNutritionsUpdated);
  }

  @Override
  public int hashCode() {
    return Objects.hash(numberofItemsUpdated, numberofProductsUpdated, numberofNutritionsUpdated);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ItemsUpdatedItems {\n");
    
    sb.append("    numberofItemsUpdated: ").append(toIndentedString(numberofItemsUpdated)).append("\n");
    sb.append("    numberofProductsUpdated: ").append(toIndentedString(numberofProductsUpdated)).append("\n");
    sb.append("    numberofNutritionsUpdated: ").append(toIndentedString(numberofNutritionsUpdated)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

