package com.cognizant.performancecheck.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class Grocery implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8823601613352703789L;
	
	private Nutritions nutritions;
	
	@XmlElement(name = "nutritions")
	public Nutritions getNutritions() {
		return nutritions;
	}

	public void setNutritions(Nutritions nutritions) {
		this.nutritions = nutritions;
	}
	

}
