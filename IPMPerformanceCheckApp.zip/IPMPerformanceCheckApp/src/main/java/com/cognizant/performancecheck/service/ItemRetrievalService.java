package com.cognizant.performancecheck.service;

import java.sql.SQLException;

import com.cognizant.performancecheck.model.ProductDetails;

public interface ItemRetrievalService {

	public ProductDetails retrieveProductDetails(String itemId)throws SQLException,Exception ;
		
}
