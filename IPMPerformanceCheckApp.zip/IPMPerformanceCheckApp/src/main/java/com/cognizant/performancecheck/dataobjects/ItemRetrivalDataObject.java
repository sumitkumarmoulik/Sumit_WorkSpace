package com.cognizant.performancecheck.dataobjects;

import java.sql.SQLException;

import com.cognizant.performancecheck.model.ProductDetails;

public interface ItemRetrivalDataObject {
	public ProductDetails retrieveProductDetails(String itemId)throws SQLException,Exception ;
}
