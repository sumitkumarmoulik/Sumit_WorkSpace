package com.cognizant.performancecheck.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class Nutrition implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5691411900994514911L;
	
	private String nutritionTitle;
	
	@XmlElement(name="title")
	public String getNutritionTitle() {
		return nutritionTitle;
	}
	
	public void setNutritionTitle(String nutritionTitle) {
		this.nutritionTitle = nutritionTitle;
	}

	private String nutritionNumberOfServings;
	
	@XmlElement(name="numberOfServings")
	public String getNutritionNumberOfServings() {
		return nutritionNumberOfServings;
	}

	public void setNutritionNumberOfServings(String nutritionNumberOfServings) {
		this.nutritionNumberOfServings = nutritionNumberOfServings;
	}

	private ServingSizes servingSizes;

	@XmlElement(name="servingSizes")
	public ServingSizes getServingSizes() {
		return servingSizes;
	}

	public void setServingSizes(ServingSizes servingSizes) {
		this.servingSizes = servingSizes;
	}
}
