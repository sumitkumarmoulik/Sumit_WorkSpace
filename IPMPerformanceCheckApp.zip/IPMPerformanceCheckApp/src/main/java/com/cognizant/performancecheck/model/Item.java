package com.cognizant.performancecheck.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Item implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2374572793016423821L;

	private String itemId;
	
	@XmlAttribute(name="id")
	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	private String itemMasterName ;
	
	@XmlElement(name = "itemMasterName")
	public String getItemMasterName() {
		return itemMasterName;
	}

	public void setItemMasterName(String itemMasterName) {
		this.itemMasterName = itemMasterName;
	}
	
	private String itemName ;
	
	@XmlElement(name = "name")
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
		
	private Products products;
	
	@XmlElement(name = "products")	
	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}
		
	private UPCS upcs;
	
	@XmlElement(name = "upcs")
	public UPCS getUpcs() {
		return upcs;
	}

	public void setUpcs(UPCS upcs) {
		this.upcs = upcs;
	}
}
