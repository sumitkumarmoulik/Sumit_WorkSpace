package com.cognizant.performancecheck.dataobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.performancecheck.constants.QueryConstants;
import com.cognizant.performancecheck.manager.DBConnectionManager;
import com.cognizant.performancecheck.model.ProductDetails;
import com.cognizant.performancecheck.model.ProductDetailsItems;

public class ItemRetrievalDataObjectImpl implements ItemRetrivalDataObject{

	@Override
	public ProductDetails retrieveProductDetails(String itemId) throws SQLException, Exception {
		Connection con = null;
		PreparedStatement ps= null;
		ResultSet rs = null;
		String query ="";
		
		ProductDetails productDetails = new ProductDetails();
		List<ProductDetailsItems> productDetailsItemArray = new ArrayList<ProductDetailsItems>();
		try {
		con = DBConnectionManager.getInsatnce().getConnection();
		query = QueryConstants.QUERY_GET_PRODUCT_DETAILS;
		ps = con.prepareStatement(query);
		ps.setString(1, itemId);
		System.out.println("we have reached ItemRetrievalDataObjectImpl"+ ps.toString());
		rs = ps.executeQuery();
		
		while(rs.next()) {
			ProductDetailsItems productDetailsItems = new ProductDetailsItems();
			System.out.println(rs.getString("ProductId"));
			productDetailsItems.setProductId(rs.getString("ProductId"));
			System.out.println(rs.getString("Type"));
			productDetailsItems.setType(rs.getString("Type"));
			System.out.println(rs.getString("Brand"));
			productDetailsItems.setBrand(rs.getString("Brand"));
			productDetailsItemArray.add(productDetailsItems);
		}
		} catch (SQLException sql) {
			con.rollback();
			throw sql;
		} catch (Exception ex) {
			con.rollback();
			throw ex;
		} finally {
			DBConnectionManager.closeResources(null, ps, con);
		}
		productDetails.setItems(productDetailsItemArray);
		System.out.println("productDetails :" + productDetails);
		return productDetails;
	}
}
