package com.cognizant.performancecheck.constants;

public class QueryConstants {
	public static final String QUERY_INSERT_TABLE_ITEM_MW_JAVA = "insert into Sumit_Test.ITEM_MW_JAVA(ItemId, itemMasterName, name, upc) values (?, ?, ?, ?)";
	public static final String QUERY_INSERT_TABLE_ITEM_PRODUCT_MW_JAVA = "insert into Sumit_Test.ITEM_PRODUCT_MW_JAVA(ItemId, ProductId, Type, Distributor, Brand, CountryOfOrigin) values (?, ?, ?, ?, ?, ?)";
	public static final String QUERY_INSERT_TABLE_ITEM_PROD_NUTRI_JAVA = "insert into Sumit_Test.ITEM_PROD_NUTRI_JAVA(ItemId, ProductId, Title, NumberOfServings, UOM) values (?, ?, ?, ?, ?)";
	
	public static final String QUERY_DROP_TABLE_ITEM_MW_JAVA = "DROP TABLE Sumit_Test.ITEM_MW_JAVA";
	public static final String QUERY_CREATE_TABLE_ITEM_MW_JAVA ="CREATE TABLE `ITEM_MW_JAVA` (`ItemId` varchar(60) NOT NULL,`itemMasterName` varchar(250) NOT NULL,`name` varchar(250) NOT NULL,`upc` varchar(50) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Items Data Storing';";
	
	public static final String QUERY_GET_PRODUCT_DETAILS ="select ITEM_PRODUCT_MW_JAVA.ProductId, ITEM_PRODUCT_MW_JAVA.Type, ITEM_PRODUCT_MW_JAVA.Brand from Sumit_Test.ITEM_PRODUCT_MW_JAVA ITEM_PRODUCT_MW_JAVA where ITEM_PRODUCT_MW_JAVA.ItemId = ?";
	
}
