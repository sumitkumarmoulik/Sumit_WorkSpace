package com.cognizant.performancecheck.service;

import java.sql.SQLException;

import com.cognizant.performancecheck.dataobjects.ItemRetrievalDataObjectImpl;
import com.cognizant.performancecheck.model.ProductDetails;

public class ItemRetrievalServiceImpl implements ItemRetrievalService {

	@Override
	public ProductDetails retrieveProductDetails(String itemId) throws SQLException, Exception {
		return new ItemRetrievalDataObjectImpl().retrieveProductDetails(itemId);
	}
}
