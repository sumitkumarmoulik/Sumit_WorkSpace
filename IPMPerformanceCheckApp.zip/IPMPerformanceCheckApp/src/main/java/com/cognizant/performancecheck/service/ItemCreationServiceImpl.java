package com.cognizant.performancecheck.service;

import java.sql.SQLException;

import com.cognizant.performancecheck.dataobjects.ItemCreationDataObjectImpl;
import com.cognizant.performancecheck.model.ItemInput;
import com.cognizant.performancecheck.model.ItemsUpdated;

public class ItemCreationServiceImpl implements ItemCreationService{

	@Override
	public ItemsUpdated createItems(ItemInput itemInput) throws SQLException, Exception {
		return new ItemCreationDataObjectImpl().createItems(itemInput);
	}

}
