package com.cognizant.performancecheck.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ProductDetails
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T04:37:54.797Z")

public class ProductDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2408987924061545457L;

	@JsonProperty("items")
	private List<ProductDetailsItems> items = new ArrayList<ProductDetailsItems>();

	/*
	 * public void setItems(List<ProductDetailsItems> items) { this.items =
	 * items; }
	 * 
	 * public ProductDetails items(List<ProductDetailsItems> items) { this.items
	 * = items; return this; }
	 */

	/*
	 * public ProductDetails addItemsItem(ProductDetailsItems itemsItem) {
	 * this.items.add(itemsItem); return this; }
	 */

	public List<ProductDetailsItems> getItems() {
		return items;
	}

	public void setItems(List<ProductDetailsItems> items) {
		this.items = items;
	}

	/**
	 * Get items
	 * 
	 * @return items
	 **/
	/*
	 * @ApiModelProperty(required = true, value = "")
	 * 
	 * @NotNull
	 * 
	 * @Valid
	 * 
	 * public List<ProductDetailsItems> getItems() { return items; }
	 * 
	 * public void setItems(List<ProductDetailsItems> items) { this.items =
	 * items; }
	 */

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		/*
		 * ProductDetails productDetails = (ProductDetails) o; return
		 * Objects.equals(this.items, productDetails.items);
		 */
		return true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode());
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ProductDetails {\n");

		sb.append("    items: ").append(toIndentedString(super.toString())).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
