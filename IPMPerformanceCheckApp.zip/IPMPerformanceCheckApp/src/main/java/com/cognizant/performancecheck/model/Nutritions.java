package com.cognizant.performancecheck.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Nutritions implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6356717239267639845L;
	
	private List<Nutrition> nutrition;
	
	@XmlElement(name = "nutrition")
	public List<Nutrition> getNutrition() {
		return nutrition;
	}

	public void setNutrition(List<Nutrition> nutrition) {
		this.nutrition = nutrition;
	}

}
