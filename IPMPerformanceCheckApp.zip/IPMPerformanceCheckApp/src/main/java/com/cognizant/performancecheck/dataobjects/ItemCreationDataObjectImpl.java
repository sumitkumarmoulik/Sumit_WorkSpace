package com.cognizant.performancecheck.dataobjects;

import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.cognizant.performancecheck.constants.QueryConstants;
import com.cognizant.performancecheck.manager.DBConnectionManager;
import com.cognizant.performancecheck.model.Item;
import com.cognizant.performancecheck.model.ItemInput;
import com.cognizant.performancecheck.model.ItemRoot;
import com.cognizant.performancecheck.model.ItemsUpdated;
import com.cognizant.performancecheck.model.ItemsUpdatedItems;
import com.cognizant.performancecheck.model.Nutrition;
import com.cognizant.performancecheck.model.Product;
import com.cognizant.performancecheck.model.ServingSize;
import com.cognizant.performancecheck.model.UPC;

public class ItemCreationDataObjectImpl implements ItemCreationDataObject {

	@Override
	public ItemsUpdated createItems(ItemInput itemInput) throws SQLException, Exception {

		Connection con = null;
		PreparedStatement ps = null;
		String Item_query = "";
		String nutri_query = "";
		String product_query = "";

		String ItemId;
		String itemMasterName;
		String name;
		String Upc = null;

		String ProductId;
		String Type;
		String Distributor;
		String Brand;
		String CountryOfOrigin;

		String Title;
		String NumberOfServings;
		String UOM = null;
		Integer Nutri_items = 0;
		Integer Product_items = 0;
		Integer Item_items = 0;
		ItemsUpdatedItems itemsUpdatedItems = new ItemsUpdatedItems();
		ItemsUpdated itemsUpdated = new ItemsUpdated();

		try {
			System.out.println("DB Connection");
			con = DBConnectionManager.getInsatnce().getConnection();
			con.setAutoCommit(false);
			// List<Item> itemlist = itemInput.getItemInputString();

			String inputString = itemInput.getItemInputString();
			String inputStringNew = "";
			inputString = inputString.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
			// itemlist.replaceAll("xmlns.*?(\"|\').*?(\"|\')", "").trim();
			inputStringNew = inputString.replace("xmlns='http://www.itemmaster.com/item' ", "");
			System.out.println("OutPut is: " + inputStringNew);

			JAXBContext jaxbContext = JAXBContext.newInstance(ItemRoot.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			StringReader reader = new StringReader(inputStringNew);
			ItemRoot itemRoot = (ItemRoot) unmarshaller.unmarshal(reader);
			List<Item> itemlist = itemRoot.getItemInputString();

			for (final Item item : itemlist) {
				System.out.println("ItemIds : " + item.getItemId());
				ItemId = item.getItemId();
				System.out.println("ItemMasterName : " + item.getItemMasterName());
				itemMasterName = item.getItemMasterName();
				System.out.println("ItemName : " + item.getItemName());
				name = item.getItemName();
				List<UPC> upclist = item.getUpcs().getUpc();
				for (final UPC upc : upclist) {
					System.out.println("UPCTypeName : " + upc.getUpcType());
					Upc = upc.getUpcType();
				}

				List<Product> productlist = item.getProducts().getProduct();
				for (final Product product : productlist) {
					System.out.println("ProductIds : " + product.getProductId());
					ProductId = product.getProductId();
					System.out.println("ProductType : " + product.getProductType());
					Type = product.getProductType();
					System.out.println("ProductDistributor : " + product.getProductDistributor());
					Distributor = product.getProductDistributor();
					System.out.println("ProductBrand : " + product.getProductBrand());
					Brand = product.getProductBrand();
					System.out.println("ProductCountryOfOrigin : " + product.getProductCountryOfOrigin());
					CountryOfOrigin = product.getProductCountryOfOrigin();

					List<Nutrition> nutritionlist = product.getGrocery().getNutritions().getNutrition();
					for (final Nutrition nutrition : nutritionlist) {
						System.out.println("Nutrition Title : " + nutrition.getNutritionTitle());
						Title = nutrition.getNutritionTitle();
						System.out.println("Nutrition NumberOfServings : " + nutrition.getNutritionNumberOfServings());
						NumberOfServings = nutrition.getNutritionNumberOfServings();

						if (nutrition.getServingSizes() != null
								&& nutrition.getServingSizes().getServingSize() != null) {
							List<ServingSize> servingSizeList = nutrition.getServingSizes().getServingSize();
							for (final ServingSize servingSize : servingSizeList) {
								System.out.println("ServingSize Uom : " + servingSize.getUom());
								//System.out.println("ServingSize Type : " + servingSize.getType());
								if(servingSize.getType().equals("other")){
									UOM = servingSize.getUom();
									System.out.println("ServingSize Type : " + UOM);
								}
							}
						} else {
							continue;
						}
						nutri_query = QueryConstants.QUERY_INSERT_TABLE_ITEM_PROD_NUTRI_JAVA;
						System.out.println("Query : " + nutri_query);
						ps = con.prepareStatement(nutri_query);
						ps.setString(1, ItemId);
						ps.setString(2, ProductId);
						ps.setString(3, Title);
						ps.setString(4, NumberOfServings);
						ps.setString(5, UOM);
						ps.executeUpdate();
						con.commit();
						Nutri_items++;
					}
					
					product_query = QueryConstants.QUERY_INSERT_TABLE_ITEM_PRODUCT_MW_JAVA;
					System.out.println("Query : " + product_query);
					ps = con.prepareStatement(product_query);
					ps.setString(1, ItemId);
					ps.setString(2, ProductId);
					ps.setString(3, Type);
					ps.setString(4, Distributor);
					ps.setString(5, Brand);
					ps.setString(6, CountryOfOrigin);
					ps.executeUpdate();
					con.commit();
					Product_items++;
				}

				Item_query = QueryConstants.QUERY_INSERT_TABLE_ITEM_MW_JAVA;
				System.out.println("Query : " + Item_query);
				ps = con.prepareStatement(Item_query);
				ps.setString(1, ItemId);
				ps.setString(2, itemMasterName);
				ps.setString(3, name);
				ps.setString(4, Upc);
				ps.executeUpdate();
				con.commit();
				Item_items++;
			}
		} catch (SQLException sql) {
			con.rollback();
			throw sql;
		} catch (Exception ex) {
			con.rollback();
			throw ex;
		} finally {
			DBConnectionManager.closeResources(null, ps, con);
		}
		itemsUpdatedItems.setNumberofItemsUpdated(Item_items);
		itemsUpdatedItems.setNumberofProductsUpdated(Product_items);
		itemsUpdatedItems.setNumberofNutritionsUpdated(Nutri_items);
		itemsUpdated.setItems(itemsUpdatedItems);
		return itemsUpdated;
	}
}
