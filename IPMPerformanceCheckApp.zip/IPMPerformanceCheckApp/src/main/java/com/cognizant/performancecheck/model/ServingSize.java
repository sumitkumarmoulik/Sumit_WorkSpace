package com.cognizant.performancecheck.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ServingSize implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6837851180924711179L;
	private String uom;
	private String type;

	@XmlElement(name = "uom")
	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}
	
	@XmlAttribute(name="type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
