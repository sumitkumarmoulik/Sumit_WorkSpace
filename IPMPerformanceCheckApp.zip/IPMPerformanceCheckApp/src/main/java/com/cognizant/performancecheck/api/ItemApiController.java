package com.cognizant.performancecheck.api;

import com.cognizant.performancecheck.model.AdvisoryMessage;
import com.cognizant.performancecheck.model.ItemInput;
import com.cognizant.performancecheck.model.ItemInputStringInfo;
import com.cognizant.performancecheck.model.ItemsUpdated;
import com.cognizant.performancecheck.model.ProductDetails;
import com.cognizant.performancecheck.service.ItemCreationServiceImpl;
import com.cognizant.performancecheck.service.ItemRetrievalServiceImpl;

import io.swagger.annotations.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.sql.SQLException;
import java.util.List;

import javax.validation.constraints.*;
import javax.validation.Valid;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T04:37:54.797Z")

@Controller
public class ItemApiController implements ItemApi {



    public ResponseEntity<ItemsUpdated> createItemDetails(@ApiParam(value = ""  )  @Valid @RequestBody ItemInput body) {
       System.out.println("We are entered inside controller");
    	// do some magic!
    	String itemInputs = "";
    	ItemsUpdated itemsUpdated = new ItemsUpdated();
    	ItemInputStringInfo itemInputStringInfo = new ItemInputStringInfo();
    	AdvisoryMessage advMessage = new AdvisoryMessage();
    	ApiResponseMessage apiResponseMessage = new ApiResponseMessage();
    	try{
    		System.out.println("We are entered inside controller   " + itemInputs.toString());
    		itemsUpdated = new ItemCreationServiceImpl().createItems(body);
    		if(itemInputs !=null){
    			itemInputStringInfo.setItem(itemInputs);
    			apiResponseMessage.setMessage(itemInputs);
    			advMessage.setFreeformText("Xml Parsed Successfully!!!");
    		}
    		
    	}catch(Exception ex) {
    		
    	}
        return new ResponseEntity<ItemsUpdated>(itemsUpdated,HttpStatus.OK);
    }

    public ResponseEntity<ProductDetails> getItemDetails(@NotNull@ApiParam(value = "ItemId", required = true) @RequestParam(value = "ItemId", required = true) String itemId) {
        // do some magic!
    	ProductDetails productDetails = new ProductDetails();
    	try {
			productDetails = new ItemRetrievalServiceImpl().retrieveProductDetails(itemId);
			System.out.println("123");
			
		} catch (SQLException e) {
			System.out.println(e); 
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return new ResponseEntity<ProductDetails>(productDetails,HttpStatus.OK);
    }

}
