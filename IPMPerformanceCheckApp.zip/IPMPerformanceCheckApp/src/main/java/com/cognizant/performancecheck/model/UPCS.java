package com.cognizant.performancecheck.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class UPCS implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3545777795631041781L;
	
	private List<UPC> upc;
	
	@XmlElement(name = "upc")
	public List<UPC> getUpc() {
		return upc;
	}
	public void setUpc(List<UPC> upc) {
		this.upc = upc;
	}	
}
