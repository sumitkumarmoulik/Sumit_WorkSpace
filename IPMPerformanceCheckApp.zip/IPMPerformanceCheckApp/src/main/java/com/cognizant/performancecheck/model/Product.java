package com.cognizant.performancecheck.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class Product implements Serializable{

	private static final long serialVersionUID = -7518921843610253386L;
	
	private String productId;
	
	@XmlAttribute(name="id")
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	private String productType;
	
	@XmlAttribute(name="type")
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	private String productDistributor;
	
	@XmlElement(name = "distributor")
	public String getProductDistributor() {
		return productDistributor;
	}
	public void setProductDistributor(String productDistributor) {
		this.productDistributor = productDistributor;
	}
	
	private String productCountryOfOrigin;
	
	@XmlElement(name = "countryOfOrigin")
	public String getProductCountryOfOrigin() {
		return productCountryOfOrigin;
	}
	public void setProductCountryOfOrigin(String productCountryOfOrigin) {
		this.productCountryOfOrigin = productCountryOfOrigin;
	}
	
	private String productBrand;
	
	@XmlElement(name = "brand")
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	
	private Grocery grocery;
	
	@XmlElement(name = "grocery")
	public Grocery getGrocery() {
		return grocery;
	}
	public void setGrocery(Grocery grocery) {
		this.grocery = grocery;
	}
	
}
