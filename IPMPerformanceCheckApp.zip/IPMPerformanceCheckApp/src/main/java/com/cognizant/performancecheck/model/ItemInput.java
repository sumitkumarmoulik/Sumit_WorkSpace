package com.cognizant.performancecheck.model;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessType;

/**
 * ItemInput
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T04:37:54.797Z")

/*@XmlRootElement(name = "items")
@XmlSeeAlso(value = Item.class)
@XmlAccessorType(XmlAccessType.FIELD)*/
/*@XmlRootElement(name = "item")
@XmlSeeAlso(value = Products.class)
@XmlAccessorType(XmlAccessType.FIELD)*/
/*public class ItemInput   {
	
	@XmlElement(name = "item")
	private List<Item> itemInputString ;
	
	
	public List<Item> getItemInputString() {
		return itemInputString;
	}



	public void setItemInputString(List<Item> itemInputString) {
		this.itemInputString = itemInputString;
	}*/
	
	
	/*@XmlElement(name = "name")
	private String itemInputString ;
	
	public String getItemInputString() {
		return itemInputString;
	}

	public void setItemInputString(String itemInputString) {
		this.itemInputString = itemInputString;
	}
	
	@XmlAttribute(name="id")
	private String itemId;
	
	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	@XmlElement(name = "products")
	private Products products;
		
	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}
	
	@XmlElement(name = "upcs")
	private UPCS upcs;
	
	
	public UPCS getUpcs() {
		return upcs;
	}

	public void setUpcs(UPCS upcs) {
		this.upcs = upcs;
	}*/

	

public class ItemInput   {

	/*@Override
	public String toString() {
		return "ItemInput [itemInputString=" + itemInputString + "]";
	}*/
	
	
  @JsonProperty("ItemInputString")
  private String itemInputString = null;

  public ItemInput itemInputString(String itemInputString) {
    this.itemInputString = itemInputString;
    return this;
  }

   /**
   * Get itemInputString
   * @return itemInputString
  **/
  @ApiModelProperty(value = "")


  public String getItemInputString() {
    return itemInputString;
  }

  public void setItemInputString(String itemInputString) {
    this.itemInputString = itemInputString;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ItemInput itemInput = (ItemInput) o;
    return Objects.equals(this.itemInputString, itemInput.itemInputString);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemInputString);
  }

  @Override
  public String toString() {
	System.out.println("string operation");
    StringBuilder sb = new StringBuilder();
    sb.append("class ItemInput {\n");
    sb.append("    itemInputString: ").append(toIndentedString(itemInputString)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
	
	
}

