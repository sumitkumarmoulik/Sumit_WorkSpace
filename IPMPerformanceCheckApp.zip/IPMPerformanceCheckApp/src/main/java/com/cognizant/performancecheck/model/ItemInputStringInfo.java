package com.cognizant.performancecheck.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ItemInputStringInfo
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-07T07:29:02.569Z")

public class ItemInputStringInfo {
	@JsonProperty("item")
	private String item = null;
	
	 public ItemInputStringInfo item(String item) {
		    this.item = item;
		    return this;
		  }
	 
	 /**
	   * The name of the item from which the request is      originating, e.g. kiosk, delta.com, etc.
	   * @return item
	  **/
	  @ApiModelProperty(value = "The name of the item from which the request is      originating, e.g. kiosk, delta.com, etc.")


	  public String getItem() {
	    return item;
	  }

	  public void setItem(String item) {
	    this.item = item;
	  }
	  
	  @Override
	  public boolean equals(java.lang.Object o) {
	    if (this == o) {
	      return true;
	    }
	    if (o == null || getClass() != o.getClass()) {
	      return false;
	    }
	    ItemInputStringInfo requestInfo = (ItemInputStringInfo) o;
	    return Objects.equals(this.item, requestInfo.item);
	  }

	  @Override
	  public int hashCode() {
	    return Objects.hash(item);
	  }

	  @Override
	  public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("class RequestInfo {\n");
	    
	    sb.append("    item: ").append(toIndentedString(item)).append("\n");
	    sb.append("}");
	    return sb.toString();
	  }

	  /**
	   * Convert the given object to string with each line indented by 4 spaces
	   * (except the first line).
	   */
	  private String toIndentedString(java.lang.Object o) {
	    if (o == null) {
	      return "null";
	    }
	    return o.toString().replace("\n", "\n    ");
	  }

}
